package Principal;

import util.Aeronaves;
import util.Militar;
import util.BancoDeDados;
import util.EntradaSaida;
import util.Automoveis;

public class Principal {
    public static void main(String[] args) {
        byte opcao;
        byte id = 1;
        byte codigo = 1;
        byte idPassaporte = 1;
        do {
            opcao = EntradaSaida.nextByte(
                "1 - Adicionar Aeronaves\n" + 
                "2 - Adicionar Automoveis\n"  +
                "3 - Listar Aeronaves\n" + 
                "4 - Listar Automoveis\n" +        
                "5 - Sair"
            );
            
            switch (opcao) {
                case 1: 
                    Aeronaves a = new Aeronaves();
                    a.setIdPassaporte(idPassaporte);
                    a.setNome(EntradaSaida.nextString("Tipo de aeronave"));
                    a.setPreco(EntradaSaida.nextDouble("Valor do passaporte R$"));
                    a.setTamanho(EntradaSaida.nextInt("Tamanho da aeronave"));
                    a.setAnoFabricacao(EntradaSaida.nextInt("Ano fabricação"));
                    a.setTaxaImposto(EntradaSaida.nextInt("Taxa de turismo % "));
                    BancoDeDados.adicionarAeronaves(a);
                    EntradaSaida.show("Aeronaves inserido com sucesso!");
                    idPassaporte++;
                    break;
                case 2:
                   Automoveis veiculo = new Automoveis();
                   veiculo.setCodigo(codigo);
                   veiculo.setNome(EntradaSaida.nextString("Marca do veículo"));
                   veiculo.setCilindrada(EntradaSaida.nextString("Potencia do motor"));
                   veiculo.setVelocidade(EntradaSaida.nextInt("Velocidade suportada do veículo"));
                   veiculo.setPreco(EntradaSaida.nextDouble("Valor do aluguel: R$"));
                   veiculo.setDescontoLoja(EntradaSaida.nextInt("% desconto"));
                   BancoDeDados.adicionarAutomoveis(veiculo);
                   EntradaSaida.show("Automoveis inserido com sucesso!");
                   codigo++;
                   break;
                    
                case 3:
                    if (BancoDeDados.getAeroporto().isEmpty()) {
                        EntradaSaida.show("Nenhum Aeronaves adicionada!");
                    } else {
                        // EntradaSaida.show(BancoDeDados.getTurma());
                        // Retirar o [] do listar Aeronaves
                        String lista = "";
                        for (Aeronaves aeronaves : BancoDeDados.getAeroporto()) {
                            lista += aeronaves;
                        }
                        EntradaSaida.show(lista);
                    }
                    break;
                
                case 4:
                    if (BancoDeDados.getAluguelcarros().isEmpty()) {
                        EntradaSaida.show("Nenhum Automoveis adicionada!");
                    } else {
                        // EntradaSaida.show(BancoDeDados.getTurma());
                        // Retirar o [] do listar Aeronaves
                        String lista = "";
                        for (Automoveis automoveis : BancoDeDados.getAluguelcarros()) {
                            lista += automoveis;
                        }
                        EntradaSaida.show(lista);
                    }
                    break;    
               
                    
            }
        } while (opcao != 5);
    }
}
