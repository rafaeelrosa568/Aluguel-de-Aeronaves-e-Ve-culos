
package util;

public class Brinquedo {
    
    private int id;
    private String nome;
    private double preco;

   
    public String getNome() {
        return nome;
    }

   
    public void setNome(String nome) {
        this.nome = nome;
    }

    
    public double getPreco() {
        return preco;
    }

   
    public void setPreco(double preco) {
        this.preco = preco;
    }

    @Override
    public String toString() {
        return " Breve brinquedo lancamento com promoção de final de ano" 
                + "\n Nome: " + getNome() 
                + "\n Preco: " + getPreco();
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
    
    
    
    
}
