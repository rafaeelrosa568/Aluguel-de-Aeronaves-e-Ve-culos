
package util;

import java.text.NumberFormat;


public class Aeronaves extends Brinquedo {
    
    private int idPassaporte;
    private int tamanho;
    private int anoFabricacao;
    private int taxaImposto;

   
     public int getTaxaImposto() {
        return taxaImposto;
    }
     
     public void setTaxaImposto(int taxaImposto) {
         this.taxaImposto = taxaImposto;
     }
     
    public int getTamanho() {
        return tamanho;
    }
    

    
    public void setTamanho(int tamanho) {
        this.tamanho = tamanho;
    }

    
    public int getAnoFabricacao() {
        return anoFabricacao;
    }

    
    public void setAnoFabricacao(int anoFabricacao) {
        this.anoFabricacao = anoFabricacao;
    }
    
    public double calcularImposto () {
        return (getPreco() * getTaxaImposto()) /100;
    }
    
    public double precoTotal() {
        return getPreco() + calcularImposto();
    }

    @Override // Utilizando Object para retornar um texto informativo através do toString
    public String toString() {
        return "\n -----------------------------------------"
                + "\n PASSAPORTE DA AERONAVES"
                + "\n Codigo passaporte: " + getIdPassaporte()
                + "\n Tipo da aeronave: " + getNome()
                + "\n Preço R$: " + NumberFormat.getCurrencyInstance().format(getPreco())
                + "\n Ano de fabricacao: " + getAnoFabricacao() 
                + "\n Tamanho da aeronave: " + getTamanho() + " metros"
                + "\n Impostos de turismo % : " + getTaxaImposto()
                + "\n Preço total: " + NumberFormat.getCurrencyInstance().format(precoTotal());
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Aeronaves other = (Aeronaves) obj;
        if (this.getIdPassaporte() != other.getIdPassaporte()) {
            return false;
        }
        return true;
    }

    
    public int getIdPassaporte() {
        return idPassaporte;
    }

    
    public void setIdPassaporte(int idPassaporte) {
        this.idPassaporte = idPassaporte;
    }

   
   
}
