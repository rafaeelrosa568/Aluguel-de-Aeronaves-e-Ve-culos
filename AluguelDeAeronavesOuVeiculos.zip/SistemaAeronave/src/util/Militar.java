package util;

public class Militar extends Aeronaves {

    private String armamento;

    
    public String getArmamento() {
        return armamento;
    }

    
    public void setArmamento(String armamento) {
        this.armamento = armamento;
    }

    @Override
    public String toString() {
        return " Breve brinquedo lancamento com promoção de final de ano"
                + "\n Nome: " + getNome()
                + "\n Preco do fardamento: " + getPreco()
                
                + "\n Tamanho do Fardamento: " + getTamanho() + " metro"
                + "\n Tipo do armamento: " + getArmamento();
    }

}
