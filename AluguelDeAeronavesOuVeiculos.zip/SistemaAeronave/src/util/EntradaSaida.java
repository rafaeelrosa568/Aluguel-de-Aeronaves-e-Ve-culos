package util;

import javax.swing.JOptionPane;

public class EntradaSaida {
    public static String nextString(String mensagem) {
        return JOptionPane.showInputDialog(mensagem);
    }
    
    public static double nextDouble(String mensagem) {
        String valor = JOptionPane.showInputDialog(mensagem);
        if (valor == null) {
            return 0;
        }
        if (valor.trim().isEmpty()) {
            return 0;
        }
        return Double.parseDouble(valor.replace(",", "."));
    }
    
    public static byte nextByte(String mensagem) {
        String valor = JOptionPane.showInputDialog(mensagem);
        if (valor == null) {
            return 0;
        }
        if (valor.trim().isEmpty()) {
            return 0;
        }
        return Byte.parseByte(valor);
    }
    public static int nextInt(String mensagem) {
        String valor = JOptionPane.showInputDialog(mensagem);
        if (valor == null) {
            return 0;
        }
        if (valor.trim().isEmpty()) {
            return 0;
        }
        return Integer.parseInt(valor);
    }
    
    public static void show(Object mensagem) {
        JOptionPane.showMessageDialog(null, mensagem);
    }
}
