
package util;

import java.text.NumberFormat;

public class Automoveis extends Brinquedo {
    
    private int codigo;
    private int velocidade;
    private String cilindrada;
    private int descontoLoja;

    
    public int getVelocidade() {
        return velocidade;
    }

    
    public void setVelocidade(int velocidade) {
        this.velocidade = velocidade;
    }

    
    public String getCilindrada() {
        return cilindrada;
    }

    
    public void setCilindrada (String cilindrada) {
        this.cilindrada = cilindrada;
    }
    
     public int getDescontoLoja() {
        return descontoLoja;
    }

    
    public void setDescontoLoja(int descontoLoja) {
        this.descontoLoja = descontoLoja;
    }
    
    
    
    public double calcularDesconto() {
        return (getPreco() * getDescontoLoja()) /100 ;
    }

    public double precoFinal() {
        return getPreco() - calcularDesconto();
    }
    @Override
    public String toString() {
        return "\n ----------------------------------------------------- "
                + "\n  LOCALIZA AUTOMOVEIS: "
                + "\n Código aluguel: " + getCodigo()
                + "\n Marca do veículo: " + getNome()
                + "\n cilindradas: " + getCilindrada() + " cavalos"
                + "\n velocidade Suportada: " + getVelocidade()
                + "\n Valor do aluguel: R$: " + NumberFormat.getCurrencyInstance().format(getPreco())
                + "\n Porcentagem de desconto % : " + getDescontoLoja() 
                + "\n Valor Total do alugle: " + NumberFormat.getCurrencyInstance().format(precoFinal());
    }

    
    
    
    public int getCodigo() {
        return codigo;
    }

    
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

}
