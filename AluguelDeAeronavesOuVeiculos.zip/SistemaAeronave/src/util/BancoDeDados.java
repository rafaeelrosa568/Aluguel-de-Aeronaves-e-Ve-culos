package util;

import java.util.ArrayList;
import util.Aeronaves;
import util.Automoveis;

public class BancoDeDados {
    private static ArrayList<Aeronaves> aeroporto = new ArrayList();
    
    public static void adicionarAeronaves(Aeronaves Aeronaves) {
        aeroporto.add(Aeronaves);
    }
    
    public static ArrayList<Aeronaves> getAeroporto() {
        return aeroporto;
    }
    
    private static ArrayList<Automoveis> aluguelcarros = new ArrayList();
    
    public static void adicionarAutomoveis(Automoveis Automoveis) {
        aluguelcarros.add(Automoveis);
    }
    
    public static ArrayList<Automoveis> getAluguelcarros() {
        return aluguelcarros;
    }
}
